package com.example.appmovilof.models

data class DataBeneficiario(
    var numeroCuenta: String,
    var ci: String,
    var nombreCompleto: String
) {
}