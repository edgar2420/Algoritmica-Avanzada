package com.example.appmovilof.models

class DataCobroQR(
    var monto: Int?,
    var cuentaDestino: Int,
    var fechaLimite: String
) {
}