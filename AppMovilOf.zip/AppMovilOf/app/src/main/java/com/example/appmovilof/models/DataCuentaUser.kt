package com.example.appmovilof.models

class DataCuentaUser(
    var id: Int,
    var numero: String,
    var saldo: Double,
    var userId: Int
) {
//    override fun toString(): String {
//        return "DataCuentaUser(id=$id, numero='$numero', saldo=$saldo, userId=$userId)"
//    }
}