package com.example.appmovilof.models

data class DataIngresoEgreso(
    var descripcion: String,
    var monto: Int?
) {
}