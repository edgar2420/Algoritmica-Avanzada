package com.example.appmovilof.models

class DataLogin(
    var email: String,
    var password: String
) {
}