package com.example.appmovilof.models

class DataMensaje(
    var message: String
) {
    override fun toString(): String {
        return "DataMensaje(message='$message')"
    }
}