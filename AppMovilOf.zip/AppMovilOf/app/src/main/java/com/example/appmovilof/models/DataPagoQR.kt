package com.example.appmovilof.models

class DataPagoQR(
    var codigo: String,
    var cuentaOrigen: Int
) {
}