package com.example.appmovilof.models

class DataQR(
    var id: Int,
    var codigo: String,
    var monto: Int,
    var cuentaDestino: Int,
    var fechaLimite: String,
    var created_at: String,
    var pagado: Int

) {
}