package com.example.appmovilof.models

class DataQRPagoRespuesta(
    var ingreso: DataMovimientoRespuesta,
    var egreso: DataMovimientoRespuesta,
    var qr: DataQR
) {
}