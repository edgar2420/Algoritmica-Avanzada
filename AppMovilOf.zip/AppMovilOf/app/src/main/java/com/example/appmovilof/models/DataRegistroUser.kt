package com.example.appmovilof.models

class DataRegistroUser(
    var nombreCompleto: String,
    var email: String,
    var password: String,
    var fechaNacimiento: String,
    var ci: String

) {
}