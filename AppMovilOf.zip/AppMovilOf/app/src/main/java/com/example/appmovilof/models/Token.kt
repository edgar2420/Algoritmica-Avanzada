package com.example.appmovilof.models

data class Token(
    var access_token: String? = null
){

}