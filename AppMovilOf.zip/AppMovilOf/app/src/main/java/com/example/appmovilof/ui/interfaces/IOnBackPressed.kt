package com.example.appmovilof.ui.interfaces

interface IOnBackPressed {
    fun onBackPressed(): Boolean
}